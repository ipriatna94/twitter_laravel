@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-body">
					<form action="{{ url('/tweet') }}" method="post">
					{{csrf_field()}}
						<div class="form-group{{ $errors->has('kicau') ? ' has-error' : '' }}">
							<input type="hidden" name="id_user" value="{{ Auth::user()->id }} ">
							<input type="text" name="kicau" class="form-control" placeholder="apa yg anda pikirkan ???">
							{!! $errors->first('kicau', '<p class="help-block">:message</p>') !!}
						</div>
						<div class="form-group">
							<input type="submit" class="btn btn-primary pull-right" value="Tweet">
						</div>
					</form>
                </div>
            </div>
        </div>
    </div>
@foreach($tweets as $tweet)
	@if($tweet->id == Auth::user()->id)
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-body">
					<div class="col-md-2 pull-right">
						<img src="http://localhost/laravel/twitter_apps/public/img/{{$tweet->foto}}" width="100px" border="0" alt="">
					</div>
					<div class="col-md-8 pull-right">
						<br><label class="pull-right">{{$tweet->name}}</label><br>
						<br><span class="pull-right">{{$tweet->kicau}}<span>
					</div>
                </div>
            </div>
        </div>
    </div>
	@else
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-body">
					<div class="col-md-2">
						<img src="http://localhost/laravel/twitter_apps/public/img/{{$tweet->foto}}" width="100px" border="0" alt="">
					</div>
					<div class="col-md-8">
						<br><label>{{$tweet->name}}</label><br>
						<br><span>{{$tweet->kicau}}<span>
					</div>
                </div>
            </div>
        </div>
    </div>
	@endif
@endforeach
</div>
@endsection
