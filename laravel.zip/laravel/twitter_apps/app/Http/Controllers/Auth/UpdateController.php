<?php

namespace App\Http\Controllers\Auth;

use App\User;
use Validator;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\UpdatessUsers;
use Illuminate\Http\Request;

class UpdateController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    /**
     * Where to redirect users after login / registration.
     *
     * @var string
     */
    /**
     * Create a new controller instance.
     *
     * @return void
     */    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return User
     */
    public function Update(Request $request, $id)
    {
		$user = User::find($id);

		if($request->file('foto')){
			$imageName = $request->id . '.' . 
				$request->file('foto')->getClientOriginalExtension();

			$request->file('foto')->move(
				base_path() . '/public/img/', $imageName
			);
			if($request->password == bcrypt($request->passwordconfirm)){
				$user->name	= $request->name;
				$user->email= $request->email;
				$user->foto	= $imageName;
			}else{
				if($request->password == $request->passwordconfirm){
					$user->name	= $request->name;
					$user->email= $request->email;
					$user->foto	= $imageName;
					$user->password= bcrypt($request->password);
				}
			}
		}else{
			if($request->password == bcrypt($request->passwordconfirm)){
				$user->name	= $request->name;
				$user->email= $request->email;
			}else{
				if($request->password == $request->passwordconfirm){
					$user->name	= $request->name;
					$user->email= $request->email;
					$user->password= bcrypt($request->password);
				}
			}
		}
		$user->save();
		return redirect('/home');
	}
}