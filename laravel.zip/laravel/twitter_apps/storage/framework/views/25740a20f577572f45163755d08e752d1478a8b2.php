<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-body">
					<form action="<?php echo e(url('/tweet')); ?>" method="post">
					<?php echo e(csrf_field()); ?>

						<div class="form-group<?php echo e($errors->has('kicau') ? ' has-error' : ''); ?>">
							<input type="hidden" name="id_user" value="<?php echo e(Auth::user()->id); ?> ">
							<input type="text" name="kicau" class="form-control" placeholder="apa yg anda pikirkan ???">
							<?php echo $errors->first('kicau', '<p class="help-block">:message</p>'); ?>

						</div>
						<div class="form-group">
							<input type="submit" class="btn btn-primary pull-right" value="Tweet">
						</div>
					</form>
                </div>
            </div>
        </div>
    </div>
<?php $__currentLoopData = $tweets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tweet): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	<?php if($tweet->id == Auth::user()->id): ?>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-body">
					<div class="col-md-2 pull-right">
						<img src="http://localhost/laravel/twitter_apps/public/img/<?php echo e($tweet->foto); ?>" width="100px" border="0" alt="">
					</div>
					<div class="col-md-8 pull-right">
						<br><label class="pull-right"><?php echo e($tweet->name); ?></label><br>
						<br><span class="pull-right"><?php echo e($tweet->kicau); ?><span>
					</div>
                </div>
            </div>
        </div>
    </div>
	<?php else: ?>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-body">
					<div class="col-md-2">
						<img src="http://localhost/laravel/twitter_apps/public/img/<?php echo e($tweet->foto); ?>" width="100px" border="0" alt="">
					</div>
					<div class="col-md-8">
						<br><label><?php echo e($tweet->name); ?></label><br>
						<br><span><?php echo e($tweet->kicau); ?><span>
					</div>
                </div>
            </div>
        </div>
    </div>
	<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>