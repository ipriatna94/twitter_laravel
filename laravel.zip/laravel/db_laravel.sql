-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               10.1.16-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win32
-- HeidiSQL Version:             9.4.0.5127
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for twitter_apps
DROP DATABASE IF EXISTS `twitter_apps`;
CREATE DATABASE IF NOT EXISTS `twitter_apps` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `twitter_apps`;

-- Dumping structure for table twitter_apps.migrations
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table twitter_apps.migrations: ~4 rows (approximately)
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
REPLACE INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(8, '2014_10_12_000000_create_users_table', 1),
	(9, '2014_10_12_100000_create_password_resets_table', 1),
	(10, '2017_01_17_035231_create_penggunas_table', 1),
	(11, '2017_01_17_100820_create_tweets_table', 2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- Dumping structure for table twitter_apps.password_resets
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table twitter_apps.password_resets: ~1 rows (approximately)
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
REPLACE INTO `password_resets` (`email`, `token`, `created_at`) VALUES
	('ipriatna94@gmail.com', '768ccd78670e6cb4ad2e589dfe2146ea14a41cb276faaf843b65231672a27aab', '2017-01-17 06:06:52');
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;

-- Dumping structure for table twitter_apps.tweets
DROP TABLE IF EXISTS `tweets`;
CREATE TABLE IF NOT EXISTS `tweets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `kicau` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table twitter_apps.tweets: ~1 rows (approximately)
/*!40000 ALTER TABLE `tweets` DISABLE KEYS */;
REPLACE INTO `tweets` (`id`, `id_user`, `kicau`, `created_at`, `updated_at`) VALUES
	(6, 6, 'hih !', '2017-01-17 12:55:08', '2017-01-17 12:55:08'),
	(7, 7, 'aduh !', '2017-01-17 13:13:20', '2017-01-17 13:13:20'),
	(8, 7, 'udah ?', '2017-01-17 13:13:26', '2017-01-17 13:13:26');
/*!40000 ALTER TABLE `tweets` ENABLE KEYS */;

-- Dumping structure for table twitter_apps.users
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `foto` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'user.png',
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table twitter_apps.users: ~0 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
REPLACE INTO `users` (`id`, `name`, `email`, `password`, `foto`, `remember_token`, `created_at`, `updated_at`) VALUES
	(6, 'Iip Priatna', 'ipriatna94@gmail.com', '$2y$10$uZ8p3u34/r3PnlnnvUTBa.YEW3gtaJ9z9HOq5nShomsmV6qtl37ui', 'contact-icon.png', '6aJ6xu22IuaX1rydUEVgmXeFbuxHHwWMv5OWn1kgRjpXXtyw8rBZuB5oFnri', '2017-01-17 12:55:01', '2017-01-17 13:15:15'),
	(7, 'Satria Aria Fandhita', 'satarifa.id@gmail.com', '$2y$10$BnPOiqUzgboxvK5gjxRNF.AzMDJ1A9gMR3vkHMP0enrVpNTxS4Zce', '6.png', '3uby2MQPPlxpJzTfeyP8auBK6RlCT8xXfAnlHPVU7qiIajURDJIVkrJEEbbn', '2017-01-17 13:13:12', '2017-01-17 13:18:16');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
